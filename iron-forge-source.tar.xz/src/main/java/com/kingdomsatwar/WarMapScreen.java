package com.kingdomsatwar;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.Comparator;
import java.util.List;

/** An actual in-game strategic map: territory, armies, zoom/pan, and movement orders. */
public final class WarMapScreen extends Screen {
    private static final int BACK=0xFF0A1019;
    private static final int PANEL=0xFF152334;
    private static final int LINE=0xFF3D5565;
    private static final int MUTED=0xFF9CACB9;
    private static final int GOLD=0xFFFFCE73;
    private static final int FRIEND=0xFF6BE0AD;
    private static final int ENEMY=0xFFFF8089;

    private final WarMapNetwork.MapSnapshot snapshot;
    private double centerX, centerZ, scale=0.60;
    private int selectedArmy=-1, targetX, targetZ;
    private boolean targetSelected;
    private String status="Select an army, then click a destination.";
    private int mapLeft,mapTop,mapWidth,mapHeight,sideX;
    private boolean dragging;
    private double moved;

    public WarMapScreen(WarMapNetwork.MapSnapshot packet){
        super(Component.literal("Kingdoms at War — Command Map"));
        this.snapshot=packet;
        centerX=packet.playerX;centerZ=packet.playerZ;
        for(WarMapNetwork.ArmyView a:packet.armies){
            if(a.owner().equals(packet.playerKingdomId)){selectedArmy=a.id();break;}
        }
    }

    @Override protected void init(){
        mapLeft=16;mapTop=44;sideX=Math.max(260,width-216);
        mapWidth=Math.max(180,sideX-mapLeft-12);mapHeight=Math.max(120,height-96);
        int w=Math.max(64,(width-sideX-26)/2);
        button(sideX+5,mapTop+155,w,20,"MARCH",b->order(false));
        button(sideX+11+w,mapTop+155,w,20,"SIEGE",b->order(true));
        button(sideX+5,mapTop+185,w,20,"CENTER",b->{centerX=snapshot.playerX;centerZ=snapshot.playerZ;});
        button(sideX+11+w,mapTop+185,w,20,"REFRESH",b->send("war map"));
        button(sideX+5,height-42,width-sideX-16,20,"CLOSE  [ESC]",b->onClose());
    }
    private void button(int x,int y,int w,int h,String label,Button.OnPress press){
        addRenderableWidget(Button.builder(Component.literal(label),press).bounds(x,y,w,h).build());
    }

    private void send(String command){
        Minecraft mc=Minecraft.getInstance();
        if(mc.player!=null)mc.player.connection.sendCommand(command);
    }
    private void order(boolean siege){
        if(selectedArmy<0) {status="Select one of your armies first.";return;}
        if(!targetSelected){status="Click a destination on the map first.";return;}
        send("war "+(siege?"siege":"march")+" "+selectedArmy+" "+targetX+" "+targetZ);
        status=(siege?"Siege":"March")+" order sent for Army #"+selectedArmy+" to "+targetX+", "+targetZ+".";
    }
    private int sx(double x){return (int)Math.round(mapLeft+mapWidth/2.0+(x-centerX)*scale);}
    private int sy(double z){return (int)Math.round(mapTop+mapHeight/2.0+(z-centerZ)*scale);}
    private double wx(double x){return centerX+(x-(mapLeft+mapWidth/2.0))/scale;}
    private double wz(double y){return centerZ+(y-(mapTop+mapHeight/2.0))/scale;}
    private boolean onMap(double x,double y){return x>=mapLeft && x<mapLeft+mapWidth && y>=mapTop && y<mapTop+mapHeight;}
    private int ownerColor(String id){
        if(snapshot.playerKingdomId.equals(id))return 0xCC398866;
        int hash=id.hashCode();
        int r=130+((hash>>>8)&63), g=60+((hash>>>17)&46), b=64+((hash>>>3)&48);
        return 0xCF000000|(r<<16)|(g<<8)|b;
    }
    private void label(GuiGraphics g,String text,int x,int y,int color){g.drawString(font,text,x,y,color,false);}
    private void rectangle(GuiGraphics g,int x1,int y1,int x2,int y2,int color){
        if(x2>x1 && y2>y1)g.fill(x1,y1,x2,y2,color);
    }
    private void border(GuiGraphics g,int x1,int y1,int x2,int y2,int color){
        rectangle(g,x1,y1,x2,y1+1,color);rectangle(g,x1,y2-1,x2,y2,color);
        rectangle(g,x1,y1+1,x1+1,y2-1,color);rectangle(g,x2-1,y1+1,x2,y2-1,color);
    }
    private void map(GuiGraphics g,int mouseX,int mouseY){
        rectangle(g,mapLeft,mapTop,mapLeft+mapWidth,mapTop+mapHeight,0xFF182F38);
        g.enableScissor(mapLeft,mapTop,mapLeft+mapWidth,mapTop+mapHeight);
        // Geographic coordinate grid (real block positions); no extra chunks are loaded.
        double left=wx(mapLeft),right=wx(mapLeft+mapWidth),top=wz(mapTop),bottom=wz(mapTop+mapHeight);
        int grid=scale>1?32:scale>.5?64:128;
        for(long x=(long)Math.floor(left/grid)*grid;x<=right;x+=grid){
            int sx=sx(x);rectangle(g,sx,mapTop,sx+1,mapTop+mapHeight,0x42399D9A);
        }
        for(long z=(long)Math.floor(top/grid)*grid;z<=bottom;z+=grid){
            int sy=sy(z);rectangle(g,mapLeft,sy,mapLeft+mapWidth,sy+1,0x42399D9A);
        }
        // Claim blocks are 16x16 Minecraft blocks, not invented geographical terrain.
        for(WarMapNetwork.ClaimView c:snapshot.claims){
            int x1=sx(c.chunkX()*16.0),y1=sy(c.chunkZ()*16.0);
            int x2=sx(c.chunkX()*16.0+16),y2=sy(c.chunkZ()*16.0+16);
            rectangle(g,x1,y1,Math.max(x1+2,x2),Math.max(y1+2,y2),ownerColor(c.owner()));
        }
        // Selected destination, rendered beneath soldiers.
        if(targetSelected){
            int x=sx(targetX),y=sy(targetZ);
            rectangle(g,x-12,y,x+13,y+1,GOLD);rectangle(g,x,y-12,x+1,y+13,GOLD);
            border(g,x-6,y-6,x+7,y+7,GOLD);
        }
        // Player position and symbol.
        int px=sx(snapshot.playerX),py=sy(snapshot.playerZ);
        border(g,px-4,py-4,px+5,py+5,0xFFFFFFFF);
        rectangle(g,px-1,py-1,px+2,py+2,0xFFFFFFFF);
        for(WarMapNetwork.ArmyView a:snapshot.armies){
            int x=sx(a.x()),y=sy(a.z());
            if(x<mapLeft-20||x>mapLeft+mapWidth+20||y<mapTop-20||y>mapTop+mapHeight+20)continue;
            int color=a.owner().equals(snapshot.playerKingdomId)?FRIEND:ENEMY;
            rectangle(g,x-7,y-7,x+8,y+8,BACK);
            rectangle(g,x-5,y-5,x+6,y+6,color);
            if(a.id()==selectedArmy)border(g,x-10,y-10,x+11,y+11,GOLD);
            label(g,""+a.id(),x+11,y-4,0xFFFFFFFF);
        }
        g.disableScissor();
        border(g,mapLeft,mapTop,mapLeft+mapWidth,mapTop+mapHeight,LINE);
        if(onMap(mouseX,mouseY)){
            int x=(int)Math.floor(wx(mouseX)),z=(int)Math.floor(wz(mouseY));
            String hover="X "+x+"   Z "+z;
            rectangle(g,mapLeft+5,mapTop+5,mapLeft+font.width(hover)+15,mapTop+20,0xE6091822);
            label(g,hover,mapLeft+9,mapTop+9,0xFFF3F7FA);
        }
    }
    private void side(GuiGraphics g,int mouseX,int mouseY){
        int sideW=width-sideX-10;
        rectangle(g,sideX,mapTop,sideX+sideW,height-53,PANEL);
        border(g,sideX,mapTop,sideX+sideW,height-53,LINE);
        label(g,snapshot.kingdom,sideX+9,mapTop+10,GOLD);
        label(g,"Food "+snapshot.food+"   Iron "+snapshot.iron,sideX+9,mapTop+27,MUTED);
        label(g,"Stone "+snapshot.stone,sideX+9,mapTop+41,MUTED);
        rectangle(g,sideX+8,mapTop+57,sideX+sideW-8,mapTop+58,LINE);
        label(g,"YOUR ARMIES",sideX+9,mapTop+65,0xFFF8F9FC);
        List<WarMapNetwork.ArmyView> owned=snapshot.armies.stream()
            .filter(a->a.owner().equals(snapshot.playerKingdomId))
            .sorted(Comparator.comparingInt(WarMapNetwork.ArmyView::id)).limit(4).toList();
        for(int i=0;i<owned.size();i++){
            WarMapNetwork.ArmyView a=owned.get(i);int yy=mapTop+83+i*18;
            if(a.id()==selectedArmy)rectangle(g,sideX+7,yy-3,sideX+sideW-7,yy+14,0xFF315264);
            label(g,"#"+a.id()+" "+kind(a.type())+"  x"+a.troops(),sideX+11,yy,
                a.id()==selectedArmy?GOLD:0xFFDAE6EA);
        }
        label(g,"SELECTED",sideX+9,mapTop+220,0xFFF8F9FC);
        WarMapNetwork.ArmyView selected=snapshot.armies.stream()
            .filter(a->a.id()==selectedArmy && a.owner().equals(snapshot.playerKingdomId))
            .findFirst().orElse(null);
        if(selected!=null){
            label(g,"Army #"+selectedArmy+" · "+kind(selected.type()),sideX+9,mapTop+237,FRIEND);
            label(g,selected.troops()+" troops  "+(selected.marching()?"Marching":"Standing"),sideX+9,mapTop+251,MUTED);
        } else label(g,"Click a green army marker",sideX+9,mapTop+240,MUTED);
        label(g,"TARGET",sideX+9,mapTop+271,0xFFF8F9FC);
        label(g,targetSelected?targetX+", "+targetZ:"Click anywhere on map",sideX+9,mapTop+286,targetSelected?GOLD:MUTED);
        label(g,"Green = yours",sideX+9,height-91,FRIEND);
        label(g,"Red = another kingdom",sideX+9,height-78,ENEMY);
        label(g,"White = you",sideX+9,height-65,0xFFEEEEEE);
    }
    private String kind(int type){return type==1?"Archers":type==2?"Cavalry":"Infantry";}

    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float partialTick){
        rectangle(g,0,0,width,height,BACK);
        label(g,"KINGDOMS AT WAR",16,12,GOLD);
        label(g,"WAR ROOM / STRATEGIC MAP",16,26,0xFFB1C4C9);
        label(g,"Zoom: mouse wheel     Pan: drag map     Orders: choose army + target",16,height-37,MUTED);
        label(g,status,16,height-23,0xFFD5E2EA);
        map(g,mouseX,mouseY);side(g,mouseX,mouseY);
        super.render(g,mouseX,mouseY,partialTick);
    }

    @Override public boolean mouseClicked(double mouseX,double mouseY,int button){
        if(super.mouseClicked(mouseX,mouseY,button))return true;
        if(button==0 && onMap(mouseX,mouseY)){
            for(WarMapNetwork.ArmyView a:snapshot.armies){
                if(a.owner().equals(snapshot.playerKingdomId)
                   && Math.abs(mouseX-sx(a.x()))<=11 && Math.abs(mouseY-sy(a.z()))<=11){
                    selectedArmy=a.id();status="Selected Army #"+a.id();return true;
                }
            }
            targetX=(int)Math.floor(wx(mouseX));targetZ=(int)Math.floor(wz(mouseY));
            targetSelected=true;moved=0;dragging=true;
            status="Target "+targetX+", "+targetZ+" selected. Click MARCH or SIEGE.";
            return true;
        }
        if(button==0 && mouseX>sideX && mouseY>=mapTop+80 && mouseY<mapTop+155){
            int index=(int)((mouseY-(mapTop+80))/18);
            List<WarMapNetwork.ArmyView> owned=snapshot.armies.stream()
                .filter(a->a.owner().equals(snapshot.playerKingdomId))
                .sorted(Comparator.comparingInt(WarMapNetwork.ArmyView::id)).limit(4).toList();
            if(index>=0 && index<owned.size()){selectedArmy=owned.get(index).id();return true;}
        }
        return false;
    }
    @Override public boolean mouseDragged(double mouseX,double mouseY,int button,double dragX,double dragY){
        if(button==0 && dragging){
            centerX-=dragX/scale;centerZ-=dragY/scale;moved+=Math.abs(dragX)+Math.abs(dragY);
            if(moved>6)targetSelected=false;
            return true;
        }
        return super.mouseDragged(mouseX,mouseY,button,dragX,dragY);
    }
    @Override public boolean mouseReleased(double mouseX,double mouseY,int button){
        if(button==0 && dragging){dragging=false;return true;}
        return super.mouseReleased(mouseX,mouseY,button);
    }
    @Override public boolean mouseScrolled(double mouseX,double mouseY,double delta){
        if(onMap(mouseX,mouseY)){
            double worldX=wx(mouseX),worldZ=wz(mouseY);
            scale=Math.max(0.07,Math.min(2.2,scale*Math.pow(1.2,delta)));
            centerX=worldX-(mouseX-(mapLeft+mapWidth/2.0))/scale;
            centerZ=worldZ-(mouseY-(mapTop+mapHeight/2.0))/scale;
            return true;
        }
        return super.mouseScrolled(mouseX,mouseY,delta);
    }
    @Override public boolean isPauseScreen(){return false;}
}
