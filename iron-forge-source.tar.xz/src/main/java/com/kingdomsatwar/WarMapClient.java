package com.kingdomsatwar;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/** Physical-client-only entry point. M opens the world strategy map. */
public final class WarMapClient {
    private static final KeyMapping MAP_KEY = new KeyMapping("key.kingdomsatwar.map",
        InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_M, "key.categories.kingdomsatwar");
    private WarMapClient(){}

    public static void open(WarMapNetwork.MapSnapshot snapshot) {
        Minecraft.getInstance().setScreen(new WarMapScreen(snapshot));
    }

    @Mod.EventBusSubscriber(modid=KingdomsAtWar.MOD_ID, value=Dist.CLIENT, bus=Mod.EventBusSubscriber.Bus.MOD)
    public static final class ModEvents {
        @SubscribeEvent public static void registerKeys(RegisterKeyMappingsEvent e) {e.register(MAP_KEY);}
    }

    @Mod.EventBusSubscriber(modid=KingdomsAtWar.MOD_ID, value=Dist.CLIENT)
    public static final class GameEvents {
        @SubscribeEvent public static void clientTick(TickEvent.ClientTickEvent e) {
            if(e.phase!=TickEvent.Phase.END)return;
            while(MAP_KEY.consumeClick()) {
                Minecraft mc=Minecraft.getInstance();
                if(mc.player!=null && mc.screen==null) mc.player.connection.sendCommand("war map");
            }
        }
    }
}
