package com.kingdomsatwar;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;

/** Vanilla-compatible slash commands and a clickable strategic map in chat. */
public final class WarCommands {
    private WarCommands() {}
    public static void register(CommandDispatcher<CommandSourceStack> d,KingdomsAtWar mod) {
        d.register(Commands.literal("war")
          .executes(c->help(c.getSource()))
          .then(Commands.literal("help").executes(c->help(c.getSource())))
          .then(Commands.literal("found")
            .then(Commands.argument("name",StringArgumentType.word())
                .executes(c->message(c.getSource(),mod.get(c.getSource().getServer()).createKingdom(
                    player(c.getSource()).getUUID(),StringArgumentType.getString(c,"name"),dim(player(c.getSource())),player(c.getSource()).getX(),player(c.getSource()).getZ())))))
          .then(Commands.literal("join")
            .then(Commands.argument("name",StringArgumentType.word()).executes(c->message(c.getSource(),
                mod.get(c.getSource().getServer()).joinKingdom(player(c.getSource()).getUUID(),StringArgumentType.getString(c,"name"))))))
          .then(Commands.literal("info").executes(c->info(c.getSource(),mod)))
          .then(Commands.literal("claims").executes(c->claims(c.getSource(),mod)))
          .then(Commands.literal("claim").executes(c->message(c.getSource(),
                mod.get(c.getSource().getServer()).claim(player(c.getSource()).getUUID(),dim(player(c.getSource())),player(c.getSource()).getX(),player(c.getSource()).getZ()))))
          .then(Commands.literal("recruit")
            .then(Commands.argument("type",StringArgumentType.word())
              .then(Commands.argument("count",IntegerArgumentType.integer(1,500)).executes(c->{
                String type=StringArgumentType.getString(c,"type").toLowerCase();
                int kind=type.equals("archers")||type.equals("archer")?1:type.equals("cavalry")?2:type.equals("infantry")?0:-1;
                ServerPlayer p=player(c.getSource());
                return message(c.getSource(),mod.get(c.getSource().getServer()).recruit(p.getUUID(),dim(p),kind,IntegerArgumentType.getInteger(c,"count"),p.getX(),p.getZ()));
              }))))
          .then(Commands.literal("armies").executes(c->armies(c.getSource(),mod)))
          .then(Commands.literal("march").then(Commands.argument("army",IntegerArgumentType.integer(1))
            .then(Commands.argument("x",IntegerArgumentType.integer(-30000000,30000000))
              .then(Commands.argument("z",IntegerArgumentType.integer(-30000000,30000000))
                .executes(c->order(c.getSource(),mod,c,false))))))
          .then(Commands.literal("siege").then(Commands.argument("army",IntegerArgumentType.integer(1))
            .then(Commands.argument("x",IntegerArgumentType.integer(-30000000,30000000))
              .then(Commands.argument("z",IntegerArgumentType.integer(-30000000,30000000))
                .executes(c->order(c.getSource(),mod,c,true))))))
          .then(Commands.literal("declare").then(Commands.argument("kingdom",StringArgumentType.word())
             .executes(c->message(c.getSource(),mod.get(c.getSource().getServer()).declare(player(c.getSource()).getUUID(),StringArgumentType.getString(c,"kingdom"))))))
          .then(Commands.literal("peace").then(Commands.argument("kingdom",StringArgumentType.word())
             .executes(c->message(c.getSource(),mod.get(c.getSource().getServer()).peace(player(c.getSource()).getUUID(),StringArgumentType.getString(c,"kingdom"))))))
          .then(Commands.literal("map").executes(c->map(c.getSource(),mod,0))
            .then(Commands.argument("army",IntegerArgumentType.integer(1)).executes(c->map(c.getSource(),mod,IntegerArgumentType.getInteger(c,"army")))))
        );
    }
    private static ServerPlayer player(CommandSourceStack source) throws CommandSyntaxException {return source.getPlayerOrException();}
    private static String dim(ServerPlayer player){return player.level().dimension().location().toString();}
    private static int message(CommandSourceStack source,String text) {source.sendSuccess(()->Component.literal("[War] "+text).withStyle(ChatFormatting.GOLD),false);return 1;}
    private static int help(CommandSourceStack s) {
        s.sendSuccess(()->Component.literal("=== KINGDOMS AT WAR ===").withStyle(ChatFormatting.GOLD),false);
        s.sendSuccess(()->Component.literal("/war found <name>  |  /war join <name>  |  /war info"),false);
        s.sendSuccess(()->Component.literal("/war claim  |  /war claims  |  /war recruit infantry|archers|cavalry <count>"),false);
        s.sendSuccess(()->Component.literal("/war armies  |  /war map [army]  |  /war march <army> <x> <z>"),false);
        s.sendSuccess(()->Component.literal("/war declare <kingdom>  |  /war siege <army> <x> <z>  |  /war peace <kingdom>"),false);
        return 1;
    }
    private static int info(CommandSourceStack s,KingdomsAtWar mod) throws CommandSyntaxException {
        WarState g=mod.get(s.getServer());WarState.Kingdom k=g.kingdom(player(s).getUUID());
        if(k==null)return message(s,"No kingdom yet. Use /war found <name> or /war join <name>.");
        long regions=g.claims.values().stream().filter(c->c.owner.equals(k.id)).count();
        int soldiers=g.armies.values().stream().filter(a->a.owner.equals(k.id)).mapToInt(a->a.troops).sum();
        s.sendSuccess(()->Component.literal("== "+k.name+" ==").withStyle(ChatFormatting.AQUA),false);
        s.sendSuccess(()->Component.literal("Food "+k.food+" | Iron "+k.iron+" | Stone "+k.stone+" | Claims "+regions+" | Troops "+soldiers),false);
        s.sendSuccess(()->Component.literal("Enemies: "+(k.wars.isEmpty()?"none":String.join(", ",k.wars))),false);
        return 1;
    }
    private static int claims(CommandSourceStack s,KingdomsAtWar mod) throws CommandSyntaxException {
        WarState g=mod.get(s.getServer());WarState.Kingdom k=g.kingdom(player(s).getUUID());
        if(k==null)return message(s,"Join a kingdom first.");
        StringBuilder sb=new StringBuilder("Claimed chunks: ");int n=0;
        for(WarState.Claim c:g.claims.values())if(c.owner.equals(k.id)) {
            if(n<15) sb.append("[").append(c.chunkX).append(",").append(c.chunkZ).append("] ");n++;
        }
        if(n>15)sb.append("... and ").append(n-15).append(" more");
        return message(s,sb.toString());
    }
    private static int armies(CommandSourceStack s,KingdomsAtWar mod) throws CommandSyntaxException {
        WarState g=mod.get(s.getServer());WarState.Kingdom k=g.kingdom(player(s).getUUID());
        if(k==null)return message(s,"Join a kingdom first.");
        s.sendSuccess(()->Component.literal("=== "+k.name+" Armies ===").withStyle(ChatFormatting.AQUA),false);
        for(WarState.Army a:g.armies.values())if(a.owner.equals(k.id)) {
            MutableComponent line=Component.literal("#"+a.id+" "+a.type()+" x"+a.troops+"  ("+(int)a.x+", "+(int)a.z+") "+(a.marching?"MARCHING":"IDLE"))
              .withStyle(st->st.withColor(ChatFormatting.GREEN).withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND,"/war map "+a.id)));
            s.sendSuccess(()->line,false);
        }
        return 1;
    }
    private static int order(CommandSourceStack s,KingdomsAtWar mod,com.mojang.brigadier.context.CommandContext<CommandSourceStack> c,boolean siege) throws CommandSyntaxException {
        return message(s,mod.get(s.getServer()).march(player(s).getUUID(),IntegerArgumentType.getInteger(c,"army"),IntegerArgumentType.getInteger(c,"x"),IntegerArgumentType.getInteger(c,"z"),siege));
    }
    private static int map(CommandSourceStack s,KingdomsAtWar mod,int armyId) throws CommandSyntaxException {
        WarState g=mod.get(s.getServer());ServerPlayer p=player(s);
        WarState.Kingdom k=g.kingdom(p.getUUID());
        if(k==null)return message(s,"Join a kingdom first.");
        WarState.Army selected=g.army(armyId);
        if(armyId==0)for(WarState.Army a:g.armies.values())if(a.owner.equals(k.id)){selected=a;break;}
        if(selected!=null && !selected.owner.equals(k.id))return message(s,"You cannot command that army.");
        final int chosen=selected==null?0:selected.id;
        int centerX=(int)Math.floor(p.getX()/64.0),centerZ=(int)Math.floor(p.getZ()/64.0);
        s.sendSuccess(()->Component.literal("=== WAR MAP | Every tile = 64 blocks | center at you ===").withStyle(ChatFormatting.GOLD),false);
        s.sendSuccess(()->Component.literal("§a■ yours   §c■ enemy   §e◆ army   §7· wild    §f+ you"),false);
        if(chosen>0)s.sendSuccess(()->Component.literal("Selected Army #"+chosen+": click any tile to send it there.").withStyle(ChatFormatting.GREEN),false);
        else s.sendSuccess(()->Component.literal("Recruit troops to activate click-to-march orders."),false);
        for(int z=-6;z<=6;z++) {
            MutableComponent row=Component.literal(String.format("%4d ", (centerZ+z)*64)).withStyle(ChatFormatting.GRAY);
            for(int x=-6;x<=6;x++) {
                int bx=(centerX+x)*64+32,bz=(centerZ+z)*64+32;
                boolean home=false,hostile=false,anyArmy=false;
                for(WarState.Claim c:g.claims.values())if(c.dimension.equals(dim(p)) && c.chunkX>=WarState.chunk(bx)-2 && c.chunkX<=WarState.chunk(bx)+2 && c.chunkZ>=WarState.chunk(bz)-2 && c.chunkZ<=WarState.chunk(bz)+2) {
                    if(c.owner.equals(k.id))home=true;else hostile=true;
                }
                for(WarState.Army a:g.armies.values())if(a.dimension.equals(dim(p)) && Math.abs(a.x-bx)<32 && Math.abs(a.z-bz)<32)anyArmy=true;
                String symbol=x==0&&z==0?"+ ":anyArmy?"◆ ":hostile?"■ ":home?"■ ":"· ";
                ChatFormatting color=x==0&&z==0?ChatFormatting.WHITE:anyArmy?ChatFormatting.YELLOW:hostile?ChatFormatting.RED:home?ChatFormatting.GREEN:ChatFormatting.DARK_GRAY;
                final String cmd="/war march "+chosen+" "+bx+" "+bz;
                MutableComponent tile=Component.literal(symbol).withStyle(st -> {
                    var style=st.withColor(color).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,Component.literal("X="+bx+", Z="+bz+(chosen>0?" | Click to march":""))));
                    return chosen>0?style.withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND,cmd)):style;
                });
                row.append(tile);
            }
            s.sendSuccess(()->row,false);
        }
        s.sendSuccess(()->Component.literal("Tip: /war map <army> selects an army; /war siege <army> <x> <z> attacks a claimed tile."),false);
        return 1;
    }
}
