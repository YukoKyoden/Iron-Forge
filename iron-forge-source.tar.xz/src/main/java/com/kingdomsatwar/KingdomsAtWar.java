package com.kingdomsatwar;

import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;
import java.nio.file.Path;

/** Forge entry point. All game simulation runs on the server main thread. */
@Mod(KingdomsAtWar.MOD_ID)
public final class KingdomsAtWar {
    public static final String MOD_ID = "kingdomsatwar";
    private MinecraftServer loadedServer;
    private WarState state;
    private final WarVisuals visuals=new WarVisuals();
    private int ticks;

    public KingdomsAtWar(){WarMapNetwork.init();MinecraftForge.EVENT_BUS.register(this);}
    private Path saveFile(MinecraftServer s) {return s.getWorldPath(LevelResource.ROOT).resolve("data/kingdomsatwar.properties");}
    private WarState state(MinecraftServer s) {
        if(state==null || loadedServer!=s) {
            if(loadedServer!=null) visuals.clear(loadedServer);
            loadedServer=s;
            try {state=WarState.load(saveFile(s));}
            catch(Exception e){System.err.println("[KingdomsAtWar] Failed loading war data: "+e);state=new WarState();}
            ticks=0;
        }
        return state;
    }
    @SubscribeEvent public void commands(RegisterCommandsEvent event) {WarCommands.register(event.getDispatcher(),this);}
    @SubscribeEvent public void serverTick(TickEvent.ServerTickEvent event) {
        if(event.phase!=TickEvent.Phase.END)return;
        MinecraftServer server=ServerLifecycleHooks.getCurrentServer();
        if(server==null)return;
        WarState game=state(server);
        if(++ticks%20!=0)return;
        game.step();
        visuals.tick(server,game);
        if(ticks%1200==0 && game.dirty())save(server);
    }
    @SubscribeEvent public void soldierKilled(LivingDeathEvent event) {
        if(!event.getEntity().getPersistentData().contains("kaw_army"))return;
        MinecraftServer server=ServerLifecycleHooks.getCurrentServer();
        if(server==null)return;
        state(server).recordCasualty(event.getEntity().getPersistentData().getInt("kaw_army"));
    }
    @SubscribeEvent public void serverStopping(ServerStoppingEvent event) {
        if(loadedServer==event.getServer()) {
            save(event.getServer()); visuals.clear(event.getServer());state=null;loadedServer=null;
        }
    }
    public WarState get(MinecraftServer s){return state(s);}
    public void save(MinecraftServer s) {
        if(state==null)return;
        try {state.save(saveFile(s));}catch(Exception e){System.err.println("[KingdomsAtWar] Could not save war data: "+e);}
    }
}
