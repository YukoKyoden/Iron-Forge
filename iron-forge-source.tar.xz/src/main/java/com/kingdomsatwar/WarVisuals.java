package com.kingdomsatwar;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.Heightmap;
import java.util.*;

/**
 * Bounded visual battlefield: zombies with vanilla AI disabled serve as combat avatars.
 * One strategic army is never expanded into one mob per troop. Proxy deaths feed back
 * into the strategic casualty count; remote battles need zero mobs and zero forced chunks.
 */
public final class WarVisuals {
    public static final int MAX_PROXIES = 48;
    private final Map<Integer,List<UUID>> avatars=new HashMap<>();
    private final Map<Integer,String> proxyDimensions=new HashMap<>();
    private final Random random=new Random(0x5ea77e);

    public void tick(MinecraftServer server,WarState game) {
        Map<Integer,Integer> requested=new LinkedHashMap<>();
        for(WarState.Battle b:game.battles()) {
            WarState.Army a=b.a(),c=b.b();
            ServerLevel world=getLevel(server,a.dimension);
            if(world==null || !isNearPlayer(server,a,c))continue;
            requested.put(a.id,Math.min(8,Math.max(1,a.troops/8)));
            requested.put(c.id,Math.min(8,Math.max(1,c.troops/8)));
        }
        // Retire avatars when there are no observers, no combat, or their army has died.
        for(Integer id:new ArrayList<>(avatars.keySet())) {
            if(!requested.containsKey(id) || game.army(id)==null) {remove(server,id);continue;}
            List<UUID> list=avatars.get(id);
            ServerLevel world=getLevel(server,proxyDimensions.get(id));
            if(world==null){avatars.remove(id);continue;}
            for(Iterator<UUID> it=list.iterator();it.hasNext();) {
                UUID uuid=it.next();
                var entity=world.getEntity(uuid);
                if(entity==null) {it.remove();continue;} // unloaded, not a casualty
                if(!entity.isAlive()) {it.remove();}
            }
            WarState.Army army=game.army(id);

            while(list.size()>requested.get(id)) {
                var entity=world.getEntity(list.remove(list.size()-1));
                if(entity!=null)entity.discard();
            }
        }
        int total=avatars.values().stream().mapToInt(List::size).sum();
        for(var req:requested.entrySet()) {
            if(total>=MAX_PROXIES)break;
            WarState.Army army=game.army(req.getKey());if(army==null || army.troops==0)continue;
            ServerLevel level=getLevel(server,army.dimension);if(level==null)continue;
            List<UUID> list=avatars.computeIfAbsent(army.id,n->new ArrayList<>());
            proxyDimensions.put(army.id,army.dimension);
            while(list.size()<req.getValue() && total<MAX_PROXIES) {
                Zombie z=EntityType.ZOMBIE.create(level);
                if(z==null)break;
                int index=list.size();
                int dx=(index%4)*2-3,dz=(index/4)*2-1;
                int x=(int)Math.floor(army.x)+dx, zz=(int)Math.floor(army.z)+dz;
                // Never force-load terrain for visuals. Players near this point should already have it loaded.
                if(!level.hasChunkAt(new BlockPos(x,64,zz)))break;
                int y=level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,x,zz);
                z.moveTo(x+.5,y,zz+.5,0,0);
                z.setNoAi(true);z.setSilent(true);z.setCanPickUpLoot(false);
                z.getPersistentData().putInt("kaw_army",army.id);
                z.setCustomName(Component.literal(army.owner+" | "+army.type()));
                z.setCustomNameVisible(false);
                z.setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(army.kind==1?Items.BOW:Items.IRON_SWORD));
                z.setItemSlot(EquipmentSlot.HEAD,new ItemStack(army.kind==2?Items.GOLDEN_HELMET:Items.IRON_HELMET));
                z.setItemSlot(EquipmentSlot.CHEST,new ItemStack(Items.IRON_CHESTPLATE));
                if(level.addFreshEntity(z)){list.add(z.getUUID());total++;}
                else break;
            }
        }
        // Low-frequency squad-level combat, not 20-tick-per-second vanilla hostile-mob AI.
        for(WarState.Battle pair:game.battles()) {
            WarState.Army a=pair.a(),b=pair.b();
            ServerLevel level=getLevel(server,a.dimension);
            if(level==null)continue;
            List<UUID> al=avatars.get(a.id),bl=avatars.get(b.id);
            if(al==null||bl==null)continue;
            fight(level,al,bl);
            fight(level,bl,al);
        }
    }
    private void fight(ServerLevel level,List<UUID> side,List<UUID> enemies) {
        for(UUID u:side) {
            var entity=level.getEntity(u);
            if(!(entity instanceof Zombie z) || !z.isAlive())continue;
            z.setRemainingFireTicks(0);
            Zombie nearest=null;double distance=Double.MAX_VALUE;
            for(UUID targetId:enemies) {
                var target=level.getEntity(targetId);
                if(!(target instanceof Zombie enemy) || !enemy.isAlive())continue;
                double dist=z.distanceToSqr(enemy);
                if(dist<distance){distance=dist;nearest=enemy;}
            }
            if(nearest==null)continue;
            double dx=nearest.getX()-z.getX(),dz=nearest.getZ()-z.getZ();
            double horizontal=Math.hypot(dx,dz);
            if(horizontal>2.5 && horizontal<25) {
                double nextX=z.getX()+dx/horizontal*.85,nextZ=z.getZ()+dz/horizontal*.85;
                int tx=(int)Math.floor(nextX),tz=(int)Math.floor(nextZ);
                if(level.hasChunkAt(new BlockPos(tx,64,tz))) {
                    int y=level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,tx,tz);
                    z.moveTo(nextX,y,nextZ,z.getYRot(),0);
                }
            } else if(distance<=10.0 && random.nextDouble()<.65) {
                z.swing(InteractionHand.MAIN_HAND);
                nearest.hurt(level.damageSources().mobAttack(z),2.0f);
            }
        }
    }
    private boolean isNearPlayer(MinecraftServer server,WarState.Army a,WarState.Army b) {
        double x=(a.x+b.x)/2,z=(a.z+b.z)/2;
        for(ServerPlayer p:server.getPlayerList().getPlayers()) {
            if(!p.level().dimension().location().toString().equals(a.dimension))continue;
            if(Math.pow(p.getX()-x,2)+Math.pow(p.getZ()-z,2)<96*96)return true;
        }
        return false;
    }
    private ServerLevel getLevel(MinecraftServer server,String dimension) {
        if(dimension==null)return null;
        for(ServerLevel level:server.getAllLevels())
            if(level.dimension().location().toString().equals(dimension))return level;
        return null;
    }
    private void remove(MinecraftServer server,int id) {
        List<UUID> list=avatars.remove(id);
        ServerLevel level=getLevel(server,proxyDimensions.remove(id));
        if(list==null || level==null)return;
        for(UUID uuid:list){var e=level.getEntity(uuid);if(e!=null)e.discard();}
    }
    public void clear(MinecraftServer server){for(int id:new ArrayList<>(avatars.keySet()))remove(server,id);}
}
