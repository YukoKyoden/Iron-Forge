package com.kingdomsatwar;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Headless deterministic-ish strategy model. No Minecraft classes are used here.
 * Armies don't consume Minecraft entities or loaded chunks when no player is present.
 */
public final class WarState {
    public static final class Kingdom {
        public String id, name, dimension;
        public UUID founder;
        public double capitalX, capitalZ;
        public int food = 350, iron = 180, stone = 90;
        public final Set<String> wars = new HashSet<>();
        public final Set<String> peaceOffers = new HashSet<>();
        public Kingdom(String id, String name, UUID founder, String dimension, double x, double z) {
            this.id=id; this.name=name; this.founder=founder; this.dimension=dimension;
            this.capitalX=x; this.capitalZ=z;
        }
    }
    public static final class Army {
        public int id, troops, kind; // kind: 0 infantry, 1 archers, 2 cavalry
        public String owner, dimension;
        public double x, z, goalX, goalZ;
        public boolean marching, sieging;
        public int siegeTicks;
        public Army(int id, String owner, String dimension, int kind, int troops, double x, double z) {
            this.id=id; this.owner=owner; this.dimension=dimension; this.kind=kind;
            this.troops=troops; this.x=x; this.z=z; this.goalX=x; this.goalZ=z;
        }
        public String type() { return switch(kind) {case 1 -> "Archers"; case 2 -> "Cavalry"; default -> "Infantry";}; }
    }
    public static final class Claim {
        public String owner, dimension;
        public int chunkX, chunkZ;
        public Claim(String owner, String dimension, int x, int z) {this.owner=owner; this.dimension=dimension; this.chunkX=x; this.chunkZ=z;}
    }
    public record Battle(Army a, Army b) { }
    public final Map<String,Kingdom> kingdoms = new LinkedHashMap<>();
    public final Map<UUID,String> membership = new LinkedHashMap<>();
    public final Map<Integer,Army> armies = new LinkedHashMap<>();
    public final Map<String,Claim> claims = new LinkedHashMap<>();
    public final List<String> news = new ArrayList<>();
    public int nextArmyId = 1;
    public long timeSeconds;
    private int tickBalance;
    private boolean dirty;

    public static String normalized(String name) {return name.toLowerCase(Locale.ROOT);}
    public static boolean validName(String name) {return name.matches("[A-Za-z][A-Za-z0-9_-]{2,19}");}
    public Kingdom kingdom(UUID player) {return kingdoms.get(membership.get(player));}
    public Army army(int id) {return armies.get(id);}
    public String claimKey(String dimension,int cx,int cz) {return dimension+"/"+cx+"/"+cz;}
    public Claim claimAt(String dimension, int cx,int cz) {return claims.get(claimKey(dimension,cx,cz));}
    public static int chunk(double block) {return (int)Math.floor(block/16.0);}

    public String createKingdom(UUID player,String name,String dimension,double x,double z) {
        if (!validName(name)) return "Use 3-20 letters, numbers, underscores or dashes; start with a letter.";
        if (membership.containsKey(player)) return "You already belong to a kingdom.";
        String id=normalized(name);
        if (kingdoms.containsKey(id)) return "That kingdom already exists.";
        if (claimAt(dimension,chunk(x),chunk(z))!=null) return "That land already belongs to another kingdom. Found yours elsewhere.";
        Kingdom k=new Kingdom(id,name,player,dimension,x,z);
        kingdoms.put(id,k); membership.put(player,id);
        claims.put(claimKey(dimension,chunk(x),chunk(z)),new Claim(id,dimension,chunk(x),chunk(z)));
        dirty=true;
        news.add(name+" has been founded!");
        return "Founded "+name+"! Your capital chunk is claimed. Supplies: 350 food, 180 iron, 90 stone.";
    }
    public String joinKingdom(UUID player,String name) {
        if(membership.containsKey(player)) return "You already belong to a kingdom.";
        Kingdom k=kingdoms.get(normalized(name));
        if(k==null) return "Unknown kingdom.";
        membership.put(player,k.id); dirty=true;
        return "Joined "+k.name+". (Open invitations in this prototype.)";
    }
    public String declare(UUID player,String other) {
        Kingdom k=kingdom(player), enemy=kingdoms.get(normalized(other));
        if(k==null) return "Create or join a kingdom first.";
        if(!k.founder.equals(player)) return "Only the kingdom founder can declare war.";
        if(enemy==null || enemy==k) return "Choose another existing kingdom.";
        k.wars.add(enemy.id); enemy.wars.add(k.id);
        k.peaceOffers.remove(enemy.id);enemy.peaceOffers.remove(k.id);dirty=true;
        news.add(k.name+" declared war on "+enemy.name+"!");
        return "WAR DECLARED against "+enemy.name+"!";
    }
    public String peace(UUID player,String other) {
        Kingdom k=kingdom(player), enemy=kingdoms.get(normalized(other));
        if(k==null || enemy==null) return "Kingdom not found.";
        if(!k.founder.equals(player)) return "Only your kingdom founder can offer peace.";
        if(!k.wars.contains(enemy.id)) return "Your kingdoms are not at war.";
        k.peaceOffers.add(enemy.id); dirty=true;
        if(enemy.peaceOffers.contains(k.id)) {
            k.peaceOffers.remove(enemy.id); enemy.peaceOffers.remove(k.id);
            k.wars.remove(enemy.id); enemy.wars.remove(k.id);
            news.add("Peace signed between "+k.name+" and "+enemy.name+"!");
            return "Peace accepted! The war has ended.";
        }
        return "Peace offered to "+enemy.name+". Their founder must also run /war peace "+k.name+".";
    }
    public void recordCasualty(int armyId) {
        Army a=armies.get(armyId);
        if(a!=null && a.troops>0){a.troops--;dirty=true;}
    }
    public String claim(UUID player,String dimension,double x,double z) {
        Kingdom k=kingdom(player); if(k==null) return "Create or join a kingdom first.";
        int cx=chunk(x),cz=chunk(z);
        if(claimAt(dimension,cx,cz)!=null) return "That chunk is already claimed.";
        if(k.stone<15) return "You need 15 stone to claim a chunk.";
        boolean adjacent=false;
        for(int dx=-1;dx<=1;dx++) for(int dz=-1;dz<=1;dz++) {
            Claim c=claimAt(dimension,cx+dx,cz+dz);
            if(c!=null && c.owner.equals(k.id)) adjacent=true;
        }
        if(!adjacent) return "Claim a chunk bordering your territory.";
        k.stone-=15;
        claims.put(claimKey(dimension,cx,cz),new Claim(k.id,dimension,cx,cz));
        dirty=true; return "Claimed chunk ("+cx+", "+cz+") for "+k.name+".";
    }
    public String recruit(UUID player,String dimension,int kind,int count,double x,double z) {
        Kingdom k=kingdom(player); if(k==null) return "Create or join a kingdom first.";
        if(count<1 || count>500) return "Recruit 1 to 500 troops per army.";
        if(kind<0 || kind>2) return "Unknown unit type.";
        int iron=count*(kind==2?4:kind==1?2:1);
        int food=count*2;
        if(k.food<food || k.iron<iron) return "Insufficient resources. Need "+food+" food and "+iron+" iron.";
        if(armies.size()>=500) return "Server army limit reached.";
        k.food-=food; k.iron-=iron;
        Army a=new Army(nextArmyId++,k.id,dimension,kind,count,x,z);
        armies.put(a.id,a); dirty=true;
        return "Recruited "+count+" "+a.type()+" into Army #"+a.id+". Use /war map "+a.id+" to command it.";
    }
    public String march(UUID player,int id,int x,int z,boolean siege) {
        Army a=armies.get(id); Kingdom k=kingdom(player);
        if(a==null) return "Unknown army number.";
        if(k==null || !a.owner.equals(k.id)) return "That isn't your army.";
        a.goalX=x; a.goalZ=z; a.marching=true; a.sieging=siege; a.siegeTicks=0; dirty=true;
        return "Army #"+id+" "+(siege?"ordered to besiege":"marching to")+" ("+x+", "+z+").";
    }
    /** Spatial-hash lookup: non-adjacent armies are never compared for battles. */
    public List<Battle> battles() {
        final int cell=25;
        Map<String,List<Army>> nearby=new HashMap<>();
        for(Army a:armies.values()) {
            if(a.troops<=0)continue;
            String key=a.dimension+"/"+(int)Math.floor(a.x/cell)+"/"+(int)Math.floor(a.z/cell);
            nearby.computeIfAbsent(key,k->new ArrayList<>()).add(a);
        }
        List<Battle> out=new ArrayList<>();
        for(Army a:armies.values()) {
            if(a.troops<=0)continue;
            Kingdom ka=kingdoms.get(a.owner);
            if(ka==null || ka.wars.isEmpty())continue;
            int cx=(int)Math.floor(a.x/cell),cz=(int)Math.floor(a.z/cell);
            for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++) {
                List<Army> rivals=nearby.get(a.dimension+"/"+(cx+dx)+"/"+(cz+dz));
                if(rivals==null)continue;
                for(Army b:rivals) {
                    if(b.id<=a.id || !ka.wars.contains(b.owner))continue;
                    if(Math.hypot(a.x-b.x,a.z-b.z)<25)out.add(new Battle(a,b));
                }
            }
        }
        return out;
    }
    /** One strategic second. Never asks Minecraft to load a chunk. */
    public void step() {
        timeSeconds++;
        for(Army a:armies.values()) {
            if(!a.marching || a.troops<=0) continue;
            double dx=a.goalX-a.x,dz=a.goalZ-a.z,dist=Math.hypot(dx,dz);
            double speed=a.kind==2?3.0:1.5; // blocks / real second
            if(dist<=speed) {a.x=a.goalX; a.z=a.goalZ; a.marching=false;}
            else {a.x+=dx/dist*speed; a.z+=dz/dist*speed;}
            dirty=true; // Persist progress even during a long march.
        }
        if(timeSeconds%4==0) {
            Set<Integer> used=new HashSet<>();
            for(Battle battle:battles()) {
                Army a=battle.a(),b=battle.b();
                if(!used.add(a.id) || !used.add(b.id)) continue;
                // Compress 100s of soldiers into a constant-time exchange per pair.
                int damageToA=Math.max(1,(int)Math.round((b.troops/60.0)*(b.kind==1?1.25:1.0)));
                int damageToB=Math.max(1,(int)Math.round((a.troops/60.0)*(a.kind==2?1.20:1.0)));
                a.troops=Math.max(0,a.troops-damageToA); b.troops=Math.max(0,b.troops-damageToB);
                a.marching=false; b.marching=false;
                if(a.troops==0) news.add("Army #"+a.id+" of "+a.owner+" was defeated!");
                if(b.troops==0) news.add("Army #"+b.id+" of "+b.owner+" was defeated!");
                dirty=true;
            }
        }
        if(timeSeconds%5==0) {
            for(Army a:armies.values()) {
                if(!a.sieging || a.marching || a.troops<=0) continue;
                Claim c=claimAt(a.dimension,chunk(a.x),chunk(a.z));
                if(c==null || c.owner.equals(a.owner)) {a.sieging=false;continue;}
                Kingdom k=kingdoms.get(a.owner);
                if(k==null || !k.wars.contains(c.owner)) {a.sieging=false; continue;}
                boolean defended=false;
                for(Army defender:armies.values()) {
                    if(defender.owner.equals(c.owner) && defender.troops>0 && defender.dimension.equals(a.dimension) && Math.hypot(defender.x-a.x,defender.z-a.z)<25) defended=true;
                }
                if(!defended) {a.siegeTicks+=5;dirty=true;}
                if(a.siegeTicks>=30) {
                    String prev=c.owner; c.owner=a.owner; a.siegeTicks=0; a.sieging=false;
                    news.add(a.owner+" captured a chunk from "+prev+" at ("+c.chunkX+", "+c.chunkZ+")!");dirty=true;
                }
            }
        }
        if(timeSeconds%60==0) {
            for(Kingdom k:kingdoms.values()) {
                long owned=claims.values().stream().filter(c->c.owner.equals(k.id)).count();
                k.food=Math.min(10000,k.food+(int)(Math.max(1,owned)*15));
                k.iron=Math.min(10000,k.iron+(int)(Math.max(1,owned)*6));
                k.stone=Math.min(10000,k.stone+(int)(Math.max(1,owned)*3));
                long total=armies.values().stream().filter(a->a.owner.equals(k.id)).mapToLong(a->a.troops).sum();
                k.food=Math.max(0,k.food-(int)(total/20));
                if(k.food==0 && total>0) {
                    for(Army a:armies.values()) if(a.owner.equals(k.id)&&a.troops>0) a.troops=Math.max(0,a.troops-1);
                }
            }
            dirty=true;
        }
        armies.values().removeIf(a->a.troops<=0);
        if(news.size()>60) news.subList(0,news.size()-60).clear();
    }
    public boolean dirty(){return dirty;}
    public void markClean(){dirty=false;}
    private static String str(Properties p,String key,String fallback) {return p.getProperty(key,fallback);}
    private static int num(Properties p,String key,int fallback) {try{return Integer.parseInt(p.getProperty(key));}catch(Exception e){return fallback;}}
    private static long lng(Properties p,String key,long fallback) {try{return Long.parseLong(p.getProperty(key));}catch(Exception e){return fallback;}}
    private static double dbl(Properties p,String key,double fallback) {try{return Double.parseDouble(p.getProperty(key));}catch(Exception e){return fallback;}}
    public void save(Path file) throws IOException {
        Properties p=new Properties();p.setProperty("format","1");p.setProperty("nextArmyId",""+nextArmyId);p.setProperty("timeSeconds",""+timeSeconds);
        p.setProperty("kingdom.ids",String.join(",",kingdoms.keySet()));
        for(Kingdom k:kingdoms.values()) {
            String pre="kingdom."+k.id+".";
            p.setProperty(pre+"name",k.name);p.setProperty(pre+"founder",k.founder.toString());p.setProperty(pre+"dimension",k.dimension);
            p.setProperty(pre+"x",""+k.capitalX);p.setProperty(pre+"z",""+k.capitalZ);
            p.setProperty(pre+"food",""+k.food);p.setProperty(pre+"iron",""+k.iron);p.setProperty(pre+"stone",""+k.stone);
            p.setProperty(pre+"wars",String.join(",",k.wars));p.setProperty(pre+"peaceOffers",String.join(",",k.peaceOffers));
        }
        for(Map.Entry<UUID,String> entry:membership.entrySet()) p.setProperty("member."+entry.getKey(),entry.getValue());
        p.setProperty("army.ids",armies.keySet().stream().map(String::valueOf).reduce((a,b)->a+","+b).orElse(""));
        for(Army a:armies.values()) {
            String pre="army."+a.id+".";
            p.setProperty(pre+"owner",a.owner);p.setProperty(pre+"dimension",a.dimension);p.setProperty(pre+"kind",""+a.kind);p.setProperty(pre+"troops",""+a.troops);
            p.setProperty(pre+"x",""+a.x);p.setProperty(pre+"z",""+a.z);p.setProperty(pre+"goalX",""+a.goalX);p.setProperty(pre+"goalZ",""+a.goalZ);
            p.setProperty(pre+"marching",""+a.marching);p.setProperty(pre+"sieging",""+a.sieging);p.setProperty(pre+"siegeTicks",""+a.siegeTicks);
        }
        p.setProperty("claim.keys",String.join(";",claims.keySet()));
        for(Claim c:claims.values()) p.setProperty("claim."+claimKey(c.dimension,c.chunkX,c.chunkZ),c.owner);
        Files.createDirectories(file.getParent());
        Path tmp=file.resolveSibling(file.getFileName()+".tmp");
        try(OutputStream out=Files.newOutputStream(tmp)) {p.store(out,"Kingdoms at War - persistent save");}
        try {Files.move(tmp,file,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}
        catch(AtomicMoveNotSupportedException e) {Files.move(tmp,file,StandardCopyOption.REPLACE_EXISTING);}
        dirty=false;
    }
    public static WarState load(Path file) throws IOException {
        WarState g=new WarState(); if(!Files.exists(file))return g;
        Properties p=new Properties();try(InputStream in=Files.newInputStream(file)){p.load(in);}
        g.nextArmyId=num(p,"nextArmyId",1);g.timeSeconds=lng(p,"timeSeconds",0);
        for(String id:str(p,"kingdom.ids","").split(",")) {
            if(id.isBlank())continue;
            String pre="kingdom."+id+".";
            try {
                Kingdom k=new Kingdom(id,str(p,pre+"name",id),UUID.fromString(str(p,pre+"founder","")),str(p,pre+"dimension","minecraft:overworld"),dbl(p,pre+"x",0),dbl(p,pre+"z",0));
                k.food=num(p,pre+"food",0);k.iron=num(p,pre+"iron",0);k.stone=num(p,pre+"stone",0);
                for(String war:str(p,pre+"wars","").split(","))if(!war.isBlank())k.wars.add(war);
                for(String offer:str(p,pre+"peaceOffers","").split(","))if(!offer.isBlank())k.peaceOffers.add(offer);
                g.kingdoms.put(id,k);
            }catch(Exception ignored){}
        }
        for(String key:p.stringPropertyNames())if(key.startsWith("member.")) {
            try {UUID uuid=UUID.fromString(key.substring(7));String id=p.getProperty(key);if(g.kingdoms.containsKey(id))g.membership.put(uuid,id);}catch(Exception ignored){}
        }
        for(String id:str(p,"army.ids","").split(",")) {
            if(id.isBlank())continue;
            try {
                int i=Integer.parseInt(id);String pre="army."+id+".";String owner=str(p,pre+"owner","");
                if(!g.kingdoms.containsKey(owner))continue;
                Army a=new Army(i,owner,str(p,pre+"dimension","minecraft:overworld"),num(p,pre+"kind",0),num(p,pre+"troops",0),dbl(p,pre+"x",0),dbl(p,pre+"z",0));
                a.goalX=dbl(p,pre+"goalX",a.x);a.goalZ=dbl(p,pre+"goalZ",a.z);
                a.marching=Boolean.parseBoolean(str(p,pre+"marching","false"));a.sieging=Boolean.parseBoolean(str(p,pre+"sieging","false"));a.siegeTicks=num(p,pre+"siegeTicks",0);
                if(a.troops>0)g.armies.put(i,a);
            }catch(Exception ignored){}
        }
        for(String key:str(p,"claim.keys","").split(";")) {
            if(key.isBlank())continue;
            int last=key.lastIndexOf('/'),prev=key.lastIndexOf('/',last-1);
            if(last<0||prev<0)continue;
            try {
                String dimension=key.substring(0,prev);
                int cx=Integer.parseInt(key.substring(prev+1,last)),cz=Integer.parseInt(key.substring(last+1));
                String owner=p.getProperty("claim."+key);
                if(g.kingdoms.containsKey(owner))g.claims.put(key,new Claim(owner,dimension,cx,cz));
            }catch(Exception ignored){}
        }
        return g;
    }
}
