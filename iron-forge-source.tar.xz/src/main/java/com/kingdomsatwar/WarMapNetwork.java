package com.kingdomsatwar;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Server-authored snapshot for the client map; never sends loaded chunk data. */
public final class WarMapNetwork {
    private static final String VERSION = "1";
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(KingdomsAtWar.MOD_ID, "map"), () -> VERSION,
        VERSION::equals, VERSION::equals);
    private static boolean registered;

    private WarMapNetwork() {}

    public static void init() {
        if (registered) return;
        registered = true;
        CHANNEL.registerMessage(0, MapSnapshot.class, MapSnapshot::encode,
            MapSnapshot::decode, MapSnapshot::handle);
    }

    public record ClaimView(int chunkX, int chunkZ, String owner) {}
    public record ArmyView(int id, String owner, int type, int troops, double x, double z,
                           boolean marching, boolean sieging) {}

    public static class MapSnapshot {
        public final String kingdom;
        public final String playerKingdomId;
        public final double playerX, playerZ;
        public final int food, iron, stone;
        public final List<ClaimView> claims;
        public final List<ArmyView> armies;

        MapSnapshot(String kingdom, String playerKingdomId, double playerX, double playerZ,
                    int food, int iron, int stone, List<ClaimView> claims, List<ArmyView> armies) {
            this.kingdom=kingdom; this.playerKingdomId=playerKingdomId;
            this.playerX=playerX;this.playerZ=playerZ;
            this.food=food;this.iron=iron;this.stone=stone;
            this.claims=claims;this.armies=armies;
        }

        public static void encode(MapSnapshot p, FriendlyByteBuf b) {
            b.writeUtf(p.kingdom, 64); b.writeUtf(p.playerKingdomId, 64);
            b.writeDouble(p.playerX); b.writeDouble(p.playerZ);
            b.writeInt(p.food);b.writeInt(p.iron);b.writeInt(p.stone);
            b.writeVarInt(p.claims.size());
            for(ClaimView c:p.claims){b.writeInt(c.chunkX());b.writeInt(c.chunkZ());b.writeUtf(c.owner(),64);}
            b.writeVarInt(p.armies.size());
            for(ArmyView a:p.armies) {
                b.writeVarInt(a.id());b.writeUtf(a.owner(),64);b.writeByte(a.type());
                b.writeVarInt(a.troops());b.writeDouble(a.x());b.writeDouble(a.z());
                b.writeBoolean(a.marching());b.writeBoolean(a.sieging());
            }
        }

        public static MapSnapshot decode(FriendlyByteBuf b) {
            String kingdom=b.readUtf(64), playerId=b.readUtf(64);
            double x=b.readDouble(),z=b.readDouble();int food=b.readInt(),iron=b.readInt(),stone=b.readInt();
            int count=b.readVarInt();if(count<0||count>8192) throw new IllegalArgumentException("Bad claim count");
            List<ClaimView> claims=new ArrayList<>(count);
            for(int i=0;i<count;i++)claims.add(new ClaimView(b.readInt(),b.readInt(),b.readUtf(64)));
            count=b.readVarInt();if(count<0||count>1024) throw new IllegalArgumentException("Bad army count");
            List<ArmyView> armies=new ArrayList<>(count);
            for(int i=0;i<count;i++)armies.add(new ArmyView(b.readVarInt(),b.readUtf(64),
                b.readUnsignedByte(),b.readVarInt(),b.readDouble(),b.readDouble(),
                b.readBoolean(),b.readBoolean()));
            return new MapSnapshot(kingdom,playerId,x,z,food,iron,stone,claims,armies);
        }

        public static void handle(MapSnapshot p, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> WarMapClient.open(p)));
            ctx.get().setPacketHandled(true);
        }
    }

    /** Only a bounded area around the player is sent, avoiding huge network messages. */
    public static boolean send(ServerPlayer player, WarState state) {
        WarState.Kingdom own=state.kingdom(player.getUUID());
        if(own==null)return false;
        String dimension=player.level().dimension().location().toString();
        List<ClaimView> claims=new ArrayList<>();
        for(WarState.Claim c:state.claims.values()) {
            if(claims.size()>=8192)break;
            if(!c.dimension.equals(dimension))continue;
            if(Math.abs(c.chunkX*16.0-player.getX())>4096 || Math.abs(c.chunkZ*16.0-player.getZ())>4096)continue;
            claims.add(new ClaimView(c.chunkX,c.chunkZ,c.owner));
        }
        List<ArmyView> armies=new ArrayList<>();
        for(WarState.Army a:state.armies.values()) {
            if(armies.size()>=1024)break;
            if(!a.dimension.equals(dimension))continue;
            if(Math.abs(a.x-player.getX())>4096 || Math.abs(a.z-player.getZ())>4096)continue;
            armies.add(new ArmyView(a.id,a.owner,a.kind,a.troops,a.x,a.z,a.marching,a.sieging));
        }
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
            new MapSnapshot(own.name,own.id,player.getX(),player.getZ(),
                own.food,own.iron,own.stone,claims,armies));
        return true;
    }
}
