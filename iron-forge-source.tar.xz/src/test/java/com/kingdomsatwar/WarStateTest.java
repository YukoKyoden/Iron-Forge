package com.kingdomsatwar;
import java.nio.file.*;
import java.util.*;

public class WarStateTest {
    static void check(boolean condition,String msg){if(!condition)throw new AssertionError(msg);}
    public static void main(String[] args) throws Exception {
        WarState g=new WarState(); UUID a=UUID.randomUUID(),b=UUID.randomUUID();
        check(g.createKingdom(a,"Redvale","minecraft:overworld",0,0).startsWith("Founded"),"found");
        check(g.createKingdom(b,"Bluehold","minecraft:overworld",48,0).startsWith("Founded"),"found second");
        UUID intruder=UUID.randomUUID();
        check(g.createKingdom(intruder,"LandGrab","minecraft:overworld",0,0).contains("already belongs"),"cannot overwrite another kingdom's claim");
        check(g.claimAt("minecraft:overworld",0,0).owner.equals("redvale"),"initial claim owner unchanged");
        check(g.kingdom(intruder)==null,"failed founder receives no kingdom");
        check(g.recruit(a,"minecraft:overworld",0,50,0,0).contains("Army #1"),"recruit");
        check(g.recruit(b,"minecraft:overworld",1,50,48,0).contains("Army #2"),"recruit2");
        check(g.declare(a,"Bluehold").contains("WAR"),"declare");
        check(g.march(a,1,48,0,false).contains("marching"),"march");
        check(g.march(b,2,0,0,false).contains("marching"),"march2");
        g.markClean();
        g.step();
        check(g.dirty(),"march progress must trigger periodic save");
        for(int i=1;i<30;i++)g.step();
        check(!g.battles().isEmpty(),"armies should meet");
        check(g.army(1).troops<50 && g.army(2).troops<50,"casualties");
        Path file=Files.createTempDirectory("kaw_test_").resolve("game.properties");
        g.save(file);WarState restored=WarState.load(file);
        check(restored.kingdoms.size()==2,"two kingdoms restored");
        check(restored.armies.size()==2,"two armies restored");
        check(restored.claims.size()==2,"two claims restored");
        check(restored.kingdom(a).food==g.kingdom(a).food,"economy persisted");
        check(restored.kingdom(b).wars.contains("redvale"),"wars persisted");
        check(restored.army(1).troops==g.army(1).troops,"casualties persisted");
        check(restored.march(a,1,42,16,true).contains("besiege"),"siege order");
        check(restored.peace(a,"Bluehold").contains("offered"),"peace offered");
        check(restored.kingdom(a).wars.contains("bluehold"),"one-sided peace cannot end war");
        check(restored.peace(b,"Redvale").contains("accepted"),"mutual peace");
        check(!restored.kingdom(a).wars.contains("bluehold"),"war ended");
        WarState s2=new WarState();UUID x=UUID.randomUUID(),y=UUID.randomUUID();
        s2.createKingdom(x,"Eastland","minecraft:overworld",0,0);
        s2.createKingdom(y,"Westland","minecraft:overworld",64,0);
        s2.declare(x,"Westland");
        s2.recruit(x,"minecraft:overworld",0,30,0,0);
        s2.march(x,1,64,0,true);
        for(int i=0;i<90;i++)s2.step();
        check(s2.claimAt("minecraft:overworld",4,0).owner.equals("eastland"),"uncontested siege captures territory");
        System.out.println("PASS: kingdom creation, recruitment, moving, war, casualties, persistence, siege orders");
    }
}
